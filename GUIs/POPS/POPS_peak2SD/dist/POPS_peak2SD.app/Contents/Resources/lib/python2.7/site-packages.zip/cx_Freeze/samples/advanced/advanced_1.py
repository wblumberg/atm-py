import sys

sys.stdout.write("Hello from cx_Freeze Advanced #1\n\n")

module = __import__("testfreeze_1")

