Aerosol Module
**************

.. automodule:: aerosol
   :members: