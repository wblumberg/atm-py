.. atmPy documentation master file, created by
   sphinx-quickstart on Thu Mar 05 13:27:42 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

   
This is a title
****************

Welcome to atmPy's documentation!
=================================

Contents:

.. toctree::
   :maxdepth: 2
   
   aerosol



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

