import sys

sys.stdout.write("importing pkg1.sub4\n")

